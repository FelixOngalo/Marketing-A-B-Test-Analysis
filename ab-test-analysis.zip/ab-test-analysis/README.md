# Marketing A/B Test Analysis

**Question:** Did showing an ad (vs a neutral PSA) increase conversion rate, and is the lift big enough to matter?

**Key findings:** *(fill in after running; state the lift, its 95% CI, and your recommendation)*

**Tools:** R, tidyverse, `prop.test`, `power.prop.test`, logistic regression, Quarto

## Reproduce

1. Get data: download the Kaggle "Marketing A/B Testing" CSV to `data/raw/marketing_AB.csv`, **or** run `source("R/00_simulate_data.R")` for simulated data (label it as simulated if you publish results).
2. `install.packages(c("tidyverse", "janitor", "broom", "scales", "quarto"))`
3. Run in order:
   - `R/01_clean.R`
   - `R/02_ab_test.R` (quick console results)
   - Render `reports/report.qmd`

## Method in brief

1. **Define** control, treatment, hypotheses, and one primary metric before looking at results.
2. **Check the data:** sample ratio mismatch (was the split as designed?) and balance on pre-treatment variables.
3. **Test:** two-proportion z-test with a 95% confidence interval on the difference.
4. **Size the effect:** absolute and relative lift, Cohen's h, and power.
5. **Stress-test:** logistic regression adjusting for day; segment view treated as exploratory.
6. **Decide:** ship, don't ship, or keep testing.

## Key concepts

| Concept | Plain-English meaning |
|---|---|
| Control / treatment | The baseline experience vs the new one being tested |
| Null hypothesis | "There is no real difference." The test asks whether the data contradict this |
| p-value | How surprising the data would be if there were truly no difference |
| Confidence interval | A plausible range for the true difference |
| Absolute vs relative lift | Percentage-point change vs percent change relative to control |
| Statistical vs practical significance | "Not noise" vs "big enough to matter" |
| Power | Chance of detecting a real effect of a given size |
| Sample ratio mismatch (SRM) | Group sizes off from the design, a red flag for a broken experiment |
| Peeking / multiple comparisons | Repeated looks or many segment slices raise the false-positive rate |

## Structure

```
R/00_get_data.R         where to get the data
R/00_simulate_data.R    simulated fallback dataset
R/cleaning.R            cleaning function
R/ab_functions.R        SRM check, lift test, effect size, power
R/01_clean.R            run cleaning
R/02_ab_test.R          run the test
reports/report.qmd      full analysis and recommendation
```

## Limitations

*(fill in)*
