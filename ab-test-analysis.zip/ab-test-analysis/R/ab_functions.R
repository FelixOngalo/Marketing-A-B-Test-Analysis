# Reusable statistical helpers for a two-group conversion A/B test.
# Convention: control = "psa", treatment = "ad".

library(dplyr)
library(tibble)

# Conversion counts and rates per group
summarise_groups <- function(df) {
  df |>
    group_by(test_group) |>
    summarise(users = n(), conversions = sum(converted),
              rate = conversions / users, .groups = "drop")
}

# Sample Ratio Mismatch: is the split between groups what the design intended?
# A mismatch usually means a bug in assignment or tracking, which invalidates the test.
srm_check <- function(df, expected_treatment_share) {
  counts <- df |> count(test_group) |> arrange(test_group)   # psa, ad
  chisq.test(x = counts$n,
             p = c(1 - expected_treatment_share, expected_treatment_share))
}

# Two-proportion test for treatment vs control.
# Returns the absolute lift, relative lift, 95% CI for the difference, and p-value.
test_difference <- function(df) {
  g <- summarise_groups(df) |> arrange(test_group)    # row 1 = control (psa), row 2 = treatment (ad)
  control   <- g[1, ]
  treatment <- g[2, ]

  pt <- prop.test(x = c(treatment$conversions, control$conversions),
                  n = c(treatment$users, control$users),
                  correct = FALSE)

  tibble(
    control_rate   = control$rate,
    treatment_rate = treatment$rate,
    abs_lift       = treatment$rate - control$rate,
    rel_lift       = (treatment$rate - control$rate) / control$rate,
    ci_low         = pt$conf.int[1],
    ci_high        = pt$conf.int[2],
    p_value        = pt$p.value
  )
}

# Cohen's h: a standard effect size for the difference between two proportions.
cohens_h <- function(p1, p2) abs(2 * asin(sqrt(p1)) - 2 * asin(sqrt(p2)))

# Users needed PER GROUP to detect a given lift with the chosen power.
required_n <- function(baseline_rate, min_detectable_rate, power = 0.8, sig_level = 0.05) {
  ceiling(power.prop.test(p1 = baseline_rate, p2 = min_detectable_rate,
                          power = power, sig.level = sig_level)$n)
}
