# Cleaning for the marketing A/B test data.

library(dplyr)
library(janitor)
library(stringr)

clean_ab <- function(raw) {
  day_levels <- c("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")

  raw |>
    clean_names() |>
    select(user_id, test_group, converted, total_ads, most_ads_day, most_ads_hour) |>
    mutate(
      test_group   = factor(str_to_lower(test_group), levels = c("psa", "ad")),  # control first
      converted    = as.character(converted) %in% c("TRUE", "True", "true", "1"),
      most_ads_day = factor(str_to_title(most_ads_day), levels = day_levels)
    ) |>
    distinct(user_id, .keep_all = TRUE)   # each user should appear once
}
