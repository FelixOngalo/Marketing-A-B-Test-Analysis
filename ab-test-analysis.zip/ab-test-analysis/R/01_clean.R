library(readr)
source("R/cleaning.R")

raw   <- read_csv("data/raw/marketing_AB.csv", show_col_types = FALSE)
clean <- clean_ab(raw)

cat("Rows before:", nrow(raw), "\n")
cat("Rows after: ", nrow(clean), "\n")
print(table(clean$test_group))

saveRDS(clean, "data/clean/ab_clean.rds")
