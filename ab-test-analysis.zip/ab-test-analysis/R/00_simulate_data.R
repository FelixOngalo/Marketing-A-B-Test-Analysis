# Simulate a marketing A/B test with the same columns as the Kaggle dataset.
# The numbers are made up for practice; do NOT report them as real findings.

library(dplyr)
library(readr)

set.seed(42)

n           <- 100000
ad_share    <- 0.96      # most traffic sees the ad; a small control group sees a PSA
p_ad        <- 0.026     # assumed true conversion rate, treatment
p_psa       <- 0.018     # assumed true conversion rate, control

days <- c("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")

sim <- tibble(
  index          = seq_len(n),
  user_id        = 1000000 + sample.int(9e6, n),
  test_group     = sample(c("ad", "psa"), n, replace = TRUE,
                          prob = c(ad_share, 1 - ad_share))
) |>
  mutate(
    converted      = runif(n) < if_else(test_group == "ad", p_ad, p_psa),
    total_ads      = pmax(1L, rpois(n, lambda = 20) + if_else(converted, 25L, 0L)),
    most_ads_day   = sample(days, n, replace = TRUE),
    most_ads_hour  = sample(0:23, n, replace = TRUE)
  ) |>
  rename(`Unnamed: 0` = index,
         `user id` = user_id,
         `test group` = test_group,
         `total ads` = total_ads,
         `most ads day` = most_ads_day,
         `most ads hour` = most_ads_hour)

dir.create("data/raw", showWarnings = FALSE, recursive = TRUE)
write_csv(sim, "data/raw/marketing_AB.csv")
message("Wrote simulated data to data/raw/marketing_AB.csv (", nrow(sim), " rows)")
