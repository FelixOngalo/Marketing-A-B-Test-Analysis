library(dplyr)
source("R/ab_functions.R")

df <- readRDS("data/clean/ab_clean.rds")

print(summarise_groups(df))
print(srm_check(df, expected_treatment_share = 0.96))   # set to your test's intended split
print(test_difference(df))
