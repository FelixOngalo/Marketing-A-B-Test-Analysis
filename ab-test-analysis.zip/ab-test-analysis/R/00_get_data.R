# Data for this project: a marketing A/B test.
#
# OPTION A (best for your portfolio): the real dataset
#   Kaggle: "Marketing A/B Testing" (search that title on kaggle.com)
#   Save the CSV as data/raw/marketing_AB.csv
#   Columns: row index, user id, test group ("ad" or "psa"), converted (True/False),
#            total ads, most ads day, most ads hour
#   "ad" = saw the real advertisement (treatment), "psa" = saw a public service
#   announcement instead (control).
#
# OPTION B (runs immediately, no download): simulated data with the same columns.
#   Run R/00_simulate_data.R. Clearly label this as simulated in your README.
#
# Either way, the rest of the pipeline is identical.

message("Use Option A (download) or Option B (source('R/00_simulate_data.R')).")
